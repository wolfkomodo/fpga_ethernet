import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import logging
import os
import sys
from cocotb.runner import get_runner
from pathlib import Path

@cocotb.test()
async def test_ethernet_transmission(dut):
    """
    Testbench for Ethernet top-level module transmission
    Capture and log signals during the frame transmission
    """
    # Create and start 100 MHz clock
    clock = Clock(dut.clk_100mhz, 10, units='ns')
    cocotb.start_soon(clock.start())

    # Initial setup and reset
    dut.eth_intn.value = 1  # Interrupt not active

    # Wait for initial frame transmission
    await Timer(1, units='ms')

    # Log key signal values during transmission
    logging.info(f"Transmission Signals:")
    logging.info(f"  eth_txen (Transmit Enable): {dut.eth_txen.value}")
    logging.info(f"  eth_txd (Transmit Data): {dut.eth_txd.value}")
    logging.info(f"  eth_refclk (Reference Clock): {dut.eth_refclk.value}")

    # Verify some basic properties of the transmission
    assert dut.eth_rstn.value == 1, "Ethernet PHY should be out of reset"

def is_runner():
    """Ethernet Testbench Runner."""
    hdl_toplevel_lang = os.getenv("HDL_TOPLEVEL_LANG", "verilog")
    sim = os.getenv("SIM", "icarus")
    proj_path = Path(__file__).resolve().parent.parent
    sys.path.append(str(proj_path / "sim" / "model"))
    sources = [proj_path / "hdl" / "top_level.sv"]
    build_test_args = ["-Wall"]
    parameters = {}
    sys.path.append(str(proj_path / "sim"))
    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel="top_level",
        always=True,
        build_args=build_test_args,
        parameters=parameters,
        timescale = ('1ns','1ps'),
        waves=True
    )
    run_test_args = []
    runner.test(
        hdl_toplevel="top_level",
        test_module="test_top_level",
        test_args=run_test_args,
        waves=True
    )

if __name__ == "__main__":
    is_runner()